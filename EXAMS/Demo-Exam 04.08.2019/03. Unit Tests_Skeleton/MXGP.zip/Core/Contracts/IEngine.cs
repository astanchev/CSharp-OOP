﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
